package br.com.controle;

public class DadosRoupas {
    private String nome;
    private Double valor;
    private String fornecedor;
    private int idroupas;
    private String tamanho;

 
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public int getIdroupas() {
        return idroupas;
    }

    public void setIdroupas(int idroupas) {
        this.idroupas = idroupas;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }
    
}