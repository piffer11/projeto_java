
package br.com.controle;

public class DadosVendas {
    private int id_vendas;
    private String metodopag;
    private String datacompra;
    private double valorFinal;
    private int cpf;

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }
    
    public int getId_vendas() {
        return id_vendas;
    }

    public void setId_vendas(int id_vendas) {
        this.id_vendas = id_vendas;
    }

    public String getMetodopag() {
        return metodopag;
    }

    public void setMetodopag(String metodopag) {
        this.metodopag = metodopag;
    }

    public String getDatacompra() {
        return datacompra;
    }

    public void setDatacompra(String datacompra) {
        this.datacompra = datacompra;
    }
    
}
