
package entidade;

import br.com.controle.DadosCliente;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class ManterCliente extends DAO{
    
          //metodo adicionar cliente
          public void inserirDados(DadosCliente dc) throws Exception {
            try {
            abrirBanco();
            String query = "INSERT INTO clientes(id_clientes, nome, cpf, email)"
                    + "values(?, ?, ?, ?)";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dc.getId_clientes());
            pst.setString(2,dc.getNome());
            pst.setInt(3,dc.getCpf());
            pst.setString(4,dc.getEmail());
            pst.execute();
            fecharBanco();
            } catch (Exception e) {
                System.out.println("Erro " + e.getMessage());
            }  
        }
          
           //metodo deletar clente		
         public void deletarClientes(DadosCliente dv) throws Exception{
            abrirBanco();
            String query = "delete from clientes where id_clientes=?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getId_clientes());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Cliente deletado com sucesso!");
            fecharBanco();
             }
         
        //listando Cliente
         public ArrayList<DadosCliente> PesquisarTudo () throws Exception {
         ArrayList<DadosCliente> cliente = new ArrayList<DadosCliente>();
         try{
         abrirBanco();  
         String query = "select * FROM clientes";
         pst = (PreparedStatement) con.prepareStatement(query);
         ResultSet tr = pst.executeQuery();
         DadosCliente dc ;
         
         while (tr.next()){
           dc = new DadosCliente();
           
           dc.setId_clientes(tr.getInt("id_clientes"));
           dc.setNome(tr.getString("nome"));
           dc.setCpf(tr.getInt("cpf"));
           dc.setEmail(tr.getString("email"));
           
           
           cliente.add(dc);
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return cliente;
     }
            
            //metodo pesquisar cliente
            public void PesquisarRegistro(DadosCliente dv) throws Exception {
        try {
            abrirBanco();
            String query = "select * FROM clientes where id_clientes=?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getId_clientes());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                dv.setId_clientes(tr.getInt("id_clientes"));
                dv.setNome(tr.getString("nome"));
                dv.setCpf(tr.getInt("cpf"));
                dv.setEmail(tr.getString("email"));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }           
           
        //metodo editar cliente
        public void editarPecas(DadosCliente a) throws Exception {
        abrirBanco();
        String query = "UPDATE clientes set nome = ?, cpf = ?, email = ? where id_clientes=?";
        
        pst = (PreparedStatement) con.prepareStatement(query);
        
        pst.setString(1, a.getNome());
        pst.setInt(2, a.getCpf());
        pst.setString(3, a.getEmail());
        pst.setInt(4, a.getId_clientes());

        pst.executeUpdate();
        fecharBanco();
        }
        
    }
