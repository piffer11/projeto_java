/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidade;

import br.com.controle.DadosRoupas;
import br.com.controle.DadosCliente;
import br.com.controle.DadosVendas;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class ManterRoupas extends DAO{
    
          //metodo adicionar roupas
          public void inserir(DadosRoupas dv) throws Exception {
            try {
            abrirBanco();
            String query = "INSERT INTO pecas(id_pecas,nome, valor, fornecedor,tamanho)"
                    + "values(?, ?, ?, ?,?)";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getIdroupas());
            pst.setString(2,dv.getNome());
            pst.setDouble(3,dv.getValor());
            pst.setString(4,dv.getFornecedor());
            pst.setString(5,dv.getTamanho());
            pst.execute();
            fecharBanco();
            } catch (Exception e) {
                System.out.println("Erro " + e.getMessage());
            }  
        }
          
           //metodo deletar roupas		
         public void deletarPecas(DadosRoupas dv) throws Exception{
            abrirBanco();
            String query = "delete from pecas where id_pecas=?";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getIdroupas());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Peça deletada com sucesso!");
            fecharBanco();
             }
         
        //listando Roupas
         public ArrayList<DadosRoupas> PesquisarTudo () throws Exception {
         ArrayList<DadosRoupas> roupas = new ArrayList<DadosRoupas>();
         try{
         abrirBanco();  
         String query = "select * FROM pecas";
         pst = (PreparedStatement) con.prepareStatement(query);
         ResultSet tr = pst.executeQuery();
         DadosRoupas dv ;
         
         while (tr.next()){
           dv = new DadosRoupas();
           
           dv.setIdroupas(tr.getInt("id_pecas"));
           dv.setNome(tr.getString("nome"));
           dv.setValor(tr.getDouble("valor"));
           dv.setFornecedor(tr.getString("fornecedor"));
           dv.setTamanho(tr.getString("tamanho"));
           
           roupas.add(dv);
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return roupas;
     }
            
            //metodo pesquisar peça
            public void PesquisarRegistro(DadosRoupas dv) throws Exception {
        try {
            abrirBanco();
            String query = "select * FROM pecas where id_pecas=?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getIdroupas());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                dv.setIdroupas(tr.getInt("id_pecas"));
                dv.setNome(tr.getString("nome"));
                dv.setValor(tr.getDouble("valor"));
                dv.setFornecedor(tr.getString("fornecedor"));
                dv.setTamanho(tr.getString("tamanho"));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }           
           
        //metodo editar peça
        public void editarPecas(DadosRoupas a) throws Exception {
        abrirBanco();
        String query = "UPDATE pecas set nome = ?, valor = ?, fornecedor = ?, tamanho = ? where id_pecas=?";
        
        pst = (PreparedStatement) con.prepareStatement(query);
        
        pst.setString(1, a.getNome());
        pst.setDouble(2, a.getValor());
        pst.setString(3, a.getFornecedor());
        pst.setString(4, a.getTamanho());
        pst.setInt(5, a.getIdroupas());

        pst.executeUpdate();
        fecharBanco();
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////      
            //metodo pesquisar id
            public void PesquisarId(DadosRoupas dv) throws Exception {
            try {
            abrirBanco();
            String query = "select * FROM pecas where id_pecas=?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getIdroupas());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                dv.setIdroupas(tr.getInt("id_pecas"));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado em pecas! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }
            
            //metodo pesquisar cpf
            public void PesquisarCPF(DadosCliente dc) throws Exception {
        try {
            abrirBanco();
            String query = "select * FROM clientes where cpf=?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dc.getCpf());
            ResultSet tr = pst.executeQuery();
            if (tr.next()) {
                dc.setCpf(tr.getInt("cpf"));
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado em cpf! ");
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }   
            
            
            //metodo para inserir na tabela compra
            public void inserirNovosDados(DadosVendas dv) throws Exception {
            try {
            abrirBanco();
            String query = "INSERT INTO vendas (id_vendas, metodo_de_pagamento, data_compra,valor_final,id_clientes.)"
                    + "values(?, ?, ? , ? , ? , ?)";
            pst=(PreparedStatement) con.prepareStatement(query);
            pst.setInt(1, dv.getId_vendas());
            pst.setString(2,dv.getMetodopag());
            pst.setString(3,dv.getDatacompra());
            pst.setDouble(4,dv.getValorFinal());
            pst.setInt(5,dv.getCpf());
            pst.execute();
            fecharBanco();
            } catch (Exception e) {
                System.out.println("Erro " + e.getMessage());
            }  
        }
            
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }
